# Ruche OS Companion 0.7 — Alpha

Application Electron pour **Windows 11**, conçue pour compléter MyDockFinder, sans modifier Windows ni installer un shell alternatif.

## Démarrage
Sur Windows avec Node.js 22 : double-cliquer `DEMARRER-WINDOWS.bat`. Ou `npm install`, `npm run check`, `npm start`. `npm run build:win` construit un exécutable portable quand l'environnement Windows est équipé de ses dépendances.

## Raccourcis
- Ctrl+Alt+F : Finder ; Ctrl+Alt+Espace : Recherche ; Ctrl+Alt+Tab : Activité ; Ctrl+Alt+Échap : quitter Ruche.
- Finder : Ctrl+T / Ctrl+N (nouvel onglet), Ctrl+W (fermer onglet), Alt+Flèche gauche/droite (historique), Entrée (ouvrir), Espace (aperçu), Échap (fermer aperçu).

## État de validation
Les tests Node valident la logique et quelques invariants statiques de fenêtre. Ni Electron graphique ni macOS ne sont présents dans l'environnement de test : rendu, DPI, fluidité MyDockFinder et installateur Windows **non testés**.

Lire `CAHIER-FENETRES-0.7.md` pour les dimensions, modules, périmètres réels et tests manuels restants.
